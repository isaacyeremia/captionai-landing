const btnStart   = document.getElementById('btnStart');
const btnStop    = document.getElementById('btnStop');
const statusText = document.getElementById('statusText');
const statusDot  = document.getElementById('statusDot');

function setActive() {
  statusText.textContent = 'Caption aktif ✓';
  statusDot.style.background = '#2ea043';
  statusText.style.color = '#2ea043';
  btnStart.style.background = '#388bfd';
  btnStart.disabled = true;
  btnStart.style.opacity = '0.6';
  btnStop.style.background = '#21262d';
  btnStop.style.color = '#f85149';
  btnStop.style.borderColor = '#f85149';
}

function setInactive() {
  statusText.textContent = 'Tidak aktif';
  statusDot.style.background = '#8b949e';
  statusText.style.color = '#8b949e';
  btnStart.style.background = '#1a73e8';
  btnStart.disabled = false;
  btnStart.style.opacity = '1';
  btnStop.style.background = '#21262d';
  btnStop.style.color = '#8b949e';
  btnStop.style.borderColor = '#30363d';
}

// Cek status saat popup dibuka
chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
  if (res && res.active) {
    setActive();
  } else {
    setInactive();
  }
});

btnStart.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.runtime.sendMessage(
      { type: 'START_CAPTION', tabId: tabs[0].id },
      (res) => {
        if (res && res.success) {
          setActive();
        } else {
          statusText.textContent = 'Gagal connect ke server';
          statusDot.style.background = '#f85149';
          statusText.style.color = '#f85149';
        }
      }
    );
  });
});

btnStop.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'STOP_CAPTION' }, () => {
    setInactive();
  });
});

btnStart.addEventListener('mouseover', () => {
  if (!btnStart.disabled) btnStart.style.background = '#1557b0';
});
btnStart.addEventListener('mouseout', () => {
  if (!btnStart.disabled) btnStart.style.background = '#1a73e8';
});
let isActive = false;
let currentTabId = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_STATUS') {
    sendResponse({ active: isActive });
    return false;
  }

  if (msg.type === 'START_CAPTION') {
    currentTabId = msg.tabId;
    isActive = true;
    chrome.tabs.sendMessage(msg.tabId, { type: 'START_CAPTURE' })
      .then(() => sendResponse({ success: true }))
      .catch((e) => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (msg.type === 'STOP_CAPTION') {
    isActive = false;
    if (currentTabId) {
      chrome.tabs.sendMessage(currentTabId, { type: 'CAPTION_STOP' });
    }
    sendResponse({ success: true });
    return false;
  }
});
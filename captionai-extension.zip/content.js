const WS_URL = 'wss://isaacyn-captionai-server.hf.space/ws';
const SAMPLE_RATE = 16000;
const CHUNK_SAMPLES = Math.floor(SAMPLE_RATE * 2.0);

let ws = null;
let audioContext = null;
let processor = null;
let source = null;
let captionBox = null;
let hideTimer = null;
let isCapturing = false;

const connectedElements = new WeakMap();

function createCaptionBox() {
  if (captionBox) return;
  captionBox = document.createElement('div');
  captionBox.id = 'captionai-box';
  captionBox.style.cssText = `
    position: fixed;
    bottom: 40px;
    left: 50%;
    transform: translateX(-50%);
    max-width: 90%;
    min-width: 400px;
    background: rgba(0, 0, 0, 0.5);
    color: #ffffff;
    font-size: 20px;
    font-family: Arial, sans-serif;
    font-weight: bold;
    padding: 12px 24px;
    border-radius: 10px;
    text-align: center;
    z-index: 999999;
    line-height: 1.6;
    border: none;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.8);
    transition: opacity 0.3s ease;
    pointer-events: none;
    word-wrap: break-word;
    white-space: normal;
  `;
  document.body.appendChild(captionBox);
}

function removeCaptionBox() {
  if (captionBox) { captionBox.remove(); captionBox = null; }
}

function showWords(text) {
  createCaptionBox();
  const words = text.trim().split(' ');

  clearTimeout(hideTimer);
  captionBox.textContent = '';
  captionBox.style.opacity = '1';

  words.forEach((word, i) => {
    setTimeout(() => {
      if (i === 0) captionBox.textContent = word;
      else captionBox.textContent += ' ' + word;

      if (i === words.length - 1) {
        hideTimer = setTimeout(() => {
          if (captionBox) {
            captionBox.textContent = '';
            captionBox.style.opacity = '0';
          }
        }, 4000);
      }
    }, i * 80);
  });
}

async function startCapture() {
  try {
    const mediaEl = document.querySelector('video') || document.querySelector('audio');
    if (!mediaEl) {
      alert('CaptionAI: Tidak ada video/audio di halaman ini.');
      return;
    }

    if (connectedElements.has(mediaEl)) {
      audioContext = connectedElements.get(mediaEl).ctx;
      source = connectedElements.get(mediaEl).src;
    } else {
      audioContext = new AudioContext({ sampleRate: SAMPLE_RATE });
      source = audioContext.createMediaElementSource(mediaEl);
      source.connect(audioContext.destination);
      connectedElements.set(mediaEl, { ctx: audioContext, src: source });
    }

    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }

    ws = new WebSocket(WS_URL);
    await new Promise((resolve, reject) => {
      ws.onopen = resolve;
      ws.onerror = () => reject(new Error('Gagal connect ke server'));
    });

    ws.onmessage = (event) => {
      if (event.data && event.data.trim()) {
        showWords(event.data.trim());
      }
    };

    ws.onclose = () => { if (isCapturing) stopCapture(); };

    processor = audioContext.createScriptProcessor(4096, 1, 1);
    source.connect(processor);
    processor.connect(audioContext.destination);

    let audioBuffer = new Float32Array(0);

    processor.onaudioprocess = (e) => {
      if (!isCapturing) return;
      const input = e.inputBuffer.getChannelData(0);
      const combined = new Float32Array(audioBuffer.length + input.length);
      combined.set(audioBuffer);
      combined.set(input, audioBuffer.length);
      audioBuffer = combined;

      while (audioBuffer.length >= CHUNK_SAMPLES) {
        const chunk = audioBuffer.slice(0, CHUNK_SAMPLES);
        audioBuffer = audioBuffer.slice(CHUNK_SAMPLES);
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(chunk.buffer);
        }
      }
    };

    isCapturing = true;
    createCaptionBox();
    captionBox.textContent = '🎧 CaptionAI aktif...';
    captionBox.style.opacity = '1';

  } catch (e) {
    alert('CaptionAI Error: ' + e.message);
  }
}

function stopCapture() {
  isCapturing = false;
  if (processor) { processor.disconnect(); processor = null; }
  if (ws) { ws.close(); ws = null; }
  clearTimeout(hideTimer);
  removeCaptionBox();
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'START_CAPTURE') startCapture();
  if (msg.type === 'CAPTION_STOP') stopCapture();
});